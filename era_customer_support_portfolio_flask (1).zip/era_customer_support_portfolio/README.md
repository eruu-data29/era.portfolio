# Era — Data Science & AI Portfolio (Flask)

## Run on Windows

1. Extract this ZIP.
2. Open PowerShell in the extracted folder.
3. Create and activate a virtual environment (optional but recommended):

   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```

4. Install dependencies:

   ```powershell
   pip install -r requirements.txt
   ```

5. Start the website:

   ```powershell
   python app.py
   ```

6. Open http://127.0.0.1:5000 in your browser.

This is a starter Flask website. The customer support agent cards are showcase/demo cards;
they do not connect to WhatsApp, a booking database, or an LLM until you add those integrations.

document.addEventListener("DOMContentLoaded", () => {
  const cards = document.querySelectorAll(".project-card, .agent-card, .section-heading, .about-note");
  cards.forEach(el => el.classList.add("reveal"));
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  cards.forEach(el => observer.observe(el));

  // Subtle pointer tilt on desktop; no external 3D library required.
  if (window.matchMedia("(hover: hover) and (pointer: fine)").matches) {
    document.querySelectorAll(".project-card, .agent-card").forEach(card => {
      card.addEventListener("mousemove", event => {
        const r = card.getBoundingClientRect();
        const x = (event.clientX - r.left) / r.width - 0.5;
        const y = (event.clientY - r.top) / r.height - 0.5;
        card.style.transform = `perspective(850px) rotateX(${-y * 2.5}deg) rotateY(${x * 2.5}deg) translateY(-3px)`;
      });
      card.addEventListener("mouseleave", () => card.style.transform = "");
    });
  }
});
